package com.example.eduhub1; // Ensure this matches your package structure

public class Note {
    private int id;
    private String name;
    private String phone;
    private String bookName;

    // Constructor
    public Note(int id, String name, String phone, String bookName) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.bookName = bookName; // Ensure bookName is set
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getBookName() {
        return bookName; // Ensure this method returns book name
    }
}