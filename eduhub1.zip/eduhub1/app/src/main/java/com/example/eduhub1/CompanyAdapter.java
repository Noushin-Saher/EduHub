package com.example.eduhub1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CompanyAdapter extends ArrayAdapter<String> {
    private final Context context;
    private final String[] companyNames;

    public CompanyAdapter(Context context, String[] companyNames) {
        super(context, R.layout.list_item_company, companyNames);
        this.context = context;
        this.companyNames = companyNames;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Inflate the custom layout for each item
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.list_item_company, parent, false);

        // Get the TextView from the custom layout and set the company name
        TextView companyNameTextView = rowView.findViewById(R.id.company_name);
        companyNameTextView.setText(companyNames[position]);

        return rowView;
    }
}
