package com.example.eduhub1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.NoteViewHolder> {
    private ArrayList<Note> noteList;
    private Context context;

    public NotesAdapter(ArrayList<Note> noteList, Context context) {
        this.noteList = noteList;
        this.context = context;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate your custom layout for each note item
        View view = LayoutInflater.from(context).inflate(R.layout.item_note, parent, false); // Use custom layout
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note note = noteList.get(position);
        holder.nameTextView.setText(note.getName());
        holder.phoneTextView.setText(note.getPhone());
        holder.bookNameTextView.setText(note.getBookName()); // Set the book name here
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public static class NoteViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView phoneTextView;
        TextView bookNameTextView; // TextView for the book name

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.textViewName); // Link to TextView in custom layout
            phoneTextView = itemView.findViewById(R.id.textViewPhone); // Link to TextView in custom layout
            bookNameTextView = itemView.findViewById(R.id.textViewBookName); // Link to TextView in custom layout
        }
    }
}