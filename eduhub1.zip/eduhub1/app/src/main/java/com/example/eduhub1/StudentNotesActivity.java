package com.example.eduhub1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StudentNotesActivity extends AppCompatActivity {

    private SQLiteHelper dbHelper; // Assuming you have a SQLiteHelper class to handle database operations
    private EditText editName;
    private EditText editPhone;
    private EditText editBookName;
    private RecyclerView recyclerView;
    private NotesAdapter adapter; // Assume this adapter displays the data
    private ArrayList<Note> noteList; // Adjust this to fit your data structure

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_notes);

        dbHelper = new SQLiteHelper(this);
        editName = findViewById(R.id.editName);
        editPhone = findViewById(R.id.editPhone);
        editBookName = findViewById(R.id.editBookName);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // Set layout manager

        // Load existing student notes
        loadNotes();

        // Submit button
        Button btnSubmit = findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(v -> {
            String name = editName.getText().toString().trim();
            String phone = editPhone.getText().toString().trim();
            String bookName = editBookName.getText().toString().trim();

            if (!name.isEmpty() && !phone.isEmpty() && !bookName.isEmpty()) {
                // Save to database
                dbHelper.addStudentNote(name, phone, bookName); // Implement this method in your SQLiteHelper
                Toast.makeText(this, "Student note saved successfully", Toast.LENGTH_SHORT).show();

                // Clear the fields
                editName.setText("");
                editPhone.setText("");
                editBookName.setText("");

                // Refresh the note list
                loadNotes();
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadNotes() {
        noteList = dbHelper.getAllStudentNotes(); // Implement this method to retrieve notes from DB
        adapter = new NotesAdapter(noteList, this); // Set the adapter
        recyclerView.setAdapter(adapter); // Use RecyclerView's setAdapter method
    }
}