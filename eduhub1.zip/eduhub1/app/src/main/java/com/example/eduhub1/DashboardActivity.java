package com.example.eduhub1;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.navigation.NavigationView;

public class DashboardActivity extends AppCompatActivity {
    public static final int nav_change_password = 2131230850; // Assuming these are your menu IDs
    public static final int nav_logout = 2131230851;          // Replace with actual menu IDs from your resources

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize the toolbar if you're using one (optional)
        Toolbar toolbar = findViewById(R.id.my_toolbar); // Assuming your activity_dashboard.xml has a Toolbar
        setSupportActionBar(toolbar);

        // Initialize DrawerLayout and NavigationView
        drawerLayout = findViewById(R.id.drawerLayout);
        NavigationView navigationView = findViewById(R.id.navigationView);

        // Configure the toggle to open/close the drawer when the menu icon is clicked
        toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Enable the toggle icon in the ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }

        // Find buttons by their IDs
        Button btnPlacedSeniors = findViewById(R.id.btnPlacedSeniors);
        Button btnStudentNotes = findViewById(R.id.btnStudentNotes);
        ImageView menuIcon = findViewById(R.id.menuIcon);

        // Handle Menu Icon click to open drawer
        menuIcon.setOnClickListener(v -> drawerLayout.openDrawer(navigationView));

        // Handle Placed Seniors button click to navigate to CompanyListActivity
        btnPlacedSeniors.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, CompanyListActivity.class);
            startActivity(intent);  // Navigate to CompanyListActivity
        });

        // Handle Student Notes button click (Navigate to StudentNotesActivity)
        btnStudentNotes.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, StudentNotesActivity.class);
            startActivity(intent);  // Start the StudentNotesActivity when "Notes" button is clicked
        });

        // Handle Navigation Drawer item clicks
        navigationView.setNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case nav_change_password:
                    Toast.makeText(DashboardActivity.this, R.string.menu_change_password, Toast.LENGTH_SHORT).show();
                    break;
                case nav_logout:
                    Toast.makeText(DashboardActivity.this, R.string.menu_logout, Toast.LENGTH_SHORT).show();
                    break;
                default:
                    return false;
            }
            drawerLayout.closeDrawers();
            return true;
        });
    }

    // Handle ActionBar toggle clicks for opening/closing drawer
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
