package com.example.eduhub1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SeniorAdapter extends RecyclerView.Adapter<SeniorAdapter.SeniorViewHolder> {

    private final String[] seniorNames;
    private final int[] seniorImages;

    public SeniorAdapter(String[] seniorNames, int[] seniorImages) {
        this.seniorNames = seniorNames;
        this.seniorImages = seniorImages;
    }

    @NonNull
    @Override
    public SeniorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_senior, parent, false);
        return new SeniorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SeniorViewHolder holder, int position) {
        holder.seniorNameTextView.setText(seniorNames[position]);
        holder.seniorImageView.setImageResource(seniorImages[position]);

        // Optional: Set a dummy LinkedIn link
        String linkedInLink = "https://www.linkedin.com/in/" + seniorNames[position].replace(" ", "").toLowerCase();
        holder.linkedInTextView.setText(linkedInLink);
    }

    @Override
    public int getItemCount() {
        return seniorNames.length;
    }

    static class SeniorViewHolder extends RecyclerView.ViewHolder {
        TextView seniorNameTextView;
        ImageView seniorImageView;
        TextView linkedInTextView;

        SeniorViewHolder(View itemView) {
            super(itemView);
            seniorNameTextView = itemView.findViewById(R.id.senior_name);
            seniorImageView = itemView.findViewById(R.id.senior_image);
            linkedInTextView = itemView.findViewById(R.id.linkedin_link);
        }
    }
}
