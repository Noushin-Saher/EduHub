package com.example.eduhub1;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class SeniorDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senior_details);

        // Retrieve the passed data from the intent
        String[] seniorNames = getIntent().getStringArrayExtra("senior_names");
        int[] seniorImages = getIntent().getIntArrayExtra("senior_images");

        // RecyclerView setup for displaying multiple seniors
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        // Adapter for the RecyclerView
        SeniorAdapter seniorAdapter = new SeniorAdapter(seniorNames, seniorImages);
        recyclerView.setAdapter(seniorAdapter);
    }
}
