package com.example.eduhub1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class CompanyListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_list);

        // Array of company names
        final String[] companyNames = getResources().getStringArray(R.array.companies);

        // Array of senior names for each company
        final String[][] seniorNamesArray = {
                {"Senior A1", "Senior A2"}, // Seniors for Company 1
                {"Senior B1", "Senior B2"}, // Seniors for Company 2
                {"Senior C1", "Senior C2"},
                {"Senior A1", "Senior A2"}, // Seniors for Company 1
                {"Senior B1", "Senior B2"}, // Seniors for Company 2
                {"Senior C1", "Senior C2"},
                {"Senior A1", "Senior A2"}// Seniors for Company 3
        };

        // Array of senior images corresponding to each company
        final int[][] seniorImagesArray = {
                {R.drawable.img_2, R.drawable.img_2}, // Images for Company 1
                {R.drawable.img_2, R.drawable.img_2}, // Images for Company 2
                {R.drawable.img_2, R.drawable.img_2},
                {R.drawable.img_2, R.drawable.img_2}, // Images for Company 2
                {R.drawable.img_2, R.drawable.img_2},
                {R.drawable.img_2, R.drawable.img_2}, // Images for Company 2
                {R.drawable.img_2, R.drawable.img_2}// Images for Company 3
        };

        // ListView setup
        ListView companyListView = findViewById(R.id.companyListView);
        CompanyAdapter adapter = new CompanyAdapter(this, companyNames);
        companyListView.setAdapter(adapter);

        // Handle company clicks
        companyListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // When a company is clicked, navigate to SeniorDetailsActivity
                Intent intent = new Intent(CompanyListActivity.this, SeniorDetailsActivity.class);

                // Pass the array of senior names and images for the selected company
                intent.putExtra("senior_names", seniorNamesArray[position]);
                intent.putExtra("senior_images", seniorImagesArray[position]);

                startActivity(intent);
            }
        });
    }
}
